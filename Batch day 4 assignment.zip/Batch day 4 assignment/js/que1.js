console.log('question 1');
function change1() {
    document.getElementById("changing_image").innerHTML = '<img src="images/work3.jpg" width="250px" >';
}
function change2() {
    document.getElementById("changing_image").innerHTML = '<img src="images/work4.jpg" width="250px"  >';

}
function change3() {
    document.getElementById("changing_image").innerHTML = '<img src="images/work5.jpg" width="250px" >';

}
//=====================Question 2  solution==============
console.log('question 2');
function Hey_Dear() {
    let txtName = document.getElementById('txtName');
    let txtOutput = document.getElementById('txtOutput');
    let name = txtName.value;
txtOutput.value = ` Hey dear ${name}......... `
}
//=====================Question 3  solution==============
console.log('question 3');
let student=[{ name:'Bharati shendurkar', age:21,country:'india',Hobbiess:'programming',},
    {name:'Dhanashree Warghat',age:24,country:'india',Hobbiess:'singing',},
    {name:'ankita kharabe',age:19, country:'india', Hobbiess:'dancing',},
    {name:'Shweta satnurkar',age:27, country:'india', Hobbiess:'reading',},
    {name:'Priyanka varpe',age:20, country:'india', Hobbiess:' dancing',},
    {name:'Prajwal Rathod',age:29, country:'india', Hobbiess:'sports',},
    {name:'Manoj Gawai',age:34, country:'india', Hobbiess:'writing',},
   
];
console.log(student);
//======Question 3 (B)Write a function to display all the objects on the console</p>==========
let obj={
    name:'Bharati shendurkar',
        age:2,
        country:'india',
        Hobbiess:'programming',
}
console.log(obj);
